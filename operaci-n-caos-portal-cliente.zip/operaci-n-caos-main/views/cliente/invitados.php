<?php
/** @var array $evento */
/** @var array $invitados */
/** @var array $rsvp */
/** @var string $estado */
$idEvento = (int) $evento['id_evento'];
$etiquetas = ['' => 'Todos', 'confirmado' => 'Confirmados', 'pendiente' => 'Pendientes', 'lista_espera' => 'Lista de espera', 'declinado' => 'Declinaron'];
?>
<div class="page-head">
    <div>
        <p class="page-head__eyebrow">Invitados · <?= e(fecha($evento['fecha_inicio'], 'd M Y')) ?></p>
        <h1><?= e($evento['nombre']) ?></h1>
        <p class="page-head__sub"><?= array_sum($rsvp) ?> invitados registrados · aforo máximo <?= (int) $evento['aforo_maximo'] ?></p>
    </div>
    <div class="page-head__acciones">
        <?php foreach ($etiquetas as $clave => $etq): ?>
            <a class="btn btn--sm <?= $estado === $clave ? 'btn--primario' : 'btn--claro' ?>" href="<?= e(url('/cliente/eventos/' . $idEvento . '/invitados' . ($clave !== '' ? '?estado=' . $clave : ''))) ?>"><?= e($etq) ?></a>
        <?php endforeach; ?>
    </div>
</div>

<div class="kpis">
    <article class="kpi kpi--oscura"><p class="kpi__top"><?= icono('check') ?> Confirmados</p><p class="kpi__valor"><?= (int) ($rsvp['confirmado'] ?? 0) ?></p><p class="kpi__nota">Asistencia segura</p></article>
    <article class="kpi"><p class="kpi__top"><?= icono('correo') ?> Pendientes</p><p class="kpi__valor"><?= (int) ($rsvp['pendiente'] ?? 0) ?></p><p class="kpi__nota">Sin respuesta todavía</p></article>
    <article class="kpi"><p class="kpi__top"><?= icono('invitados') ?> Lista de espera</p><p class="kpi__valor"><?= (int) ($rsvp['lista_espera'] ?? 0) ?></p><p class="kpi__nota">Se liberan con las bajas</p></article>
</div>

<section class="card">
    <?php if ($invitados === []): ?>
        <div class="empty">
            <div class="empty__icono"><?= icono('invitados') ?></div>
            <h3>Sin invitados en esta vista</h3>
            <p>Tu coordinador carga la lista de invitados. Si ya la enviaste, pídele que la importe.</p>
        </div>
    <?php else: ?>
        <div class="tabla-wrap">
            <table class="tabla">
                <thead><tr><th>Invitado</th><th>Categoría</th><th>Respuesta</th><th>Alimentación</th><th>Mesa</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($invitados as $i): ?>
                    <tr>
                        <td><b><?= e($i['nombre']) ?></b><?= $i['checkin_en'] ? '<span class="texto-muted texto-xs">Llegó ' . e(fecha_hora($i['checkin_en'])) . '</span>' : '' ?></td>
                        <td><?= e(ucfirst($i['categoria'])) ?></td>
                        <td><?= badge_estado($i['estado_rsvp']) ?></td>
                        <td class="texto-sm"><?= e($i['restriccion_alimenticia'] === 'ninguna' ? '—' : ucfirst(str_replace('_', ' ', $i['restriccion_alimenticia']))) ?><?= $i['alergias'] ? '<span class="texto-muted texto-xs">' . e($i['alergias']) . '</span>' : '' ?></td>
                        <td><?= e($i['mesa'] ?? '—') ?></td>
                        <td class="num"><button class="btn btn--fantasma btn--xs" type="button" data-copiar="<?= e(url('/rsvp?token=' . $i['token_acceso'])) ?>"><?= icono('externo') ?> Copiar RSVP</button></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
