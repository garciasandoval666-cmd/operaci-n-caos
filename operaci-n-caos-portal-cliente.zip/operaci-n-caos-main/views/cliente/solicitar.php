<?php
/** @var array $cliente */
/** @var array $tipos */
?>
<div class="page-head">
    <div>
        <p class="page-head__eyebrow">Portal del cliente</p>
        <h1>Solicitar un evento</h1>
        <p class="page-head__sub">Cuéntanos qué quieres celebrar. Tu ejecutivo comercial recibe la solicitud y te contacta con una propuesta.</p>
    </div>
    <div class="page-head__acciones"><a class="btn btn--fantasma" href="<?= e(url('/cliente')) ?>"><?= icono('atras') ?> Cancelar</a></div>
</div>

<section class="card">
    <div class="card__head"><div><h2>Datos del evento</h2><p>Solicitando como <b><?= e($cliente['nombre']) ?></b> · <?= e($cliente['correo']) ?></p></div></div>
    <div class="card__body">
        <form class="formulario" method="post" action="<?= e(url('/cliente/solicitar')) ?>" novalidate>
            <?= csrf_field() ?>
            <div class="campo-fila">
                <div class="campo">
                    <label for="tipo_evento">Tipo de evento <span class="campo__req">*</span></label>
                    <select class="select" id="tipo_evento" name="tipo_evento" required>
                        <option value="">Elige uno…</option>
                        <?php foreach ($tipos as $t): ?>
                            <option value="<?= e($t) ?>" <?= viejo('tipo_evento') === $t ? 'selected' : '' ?>><?= e($t) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="campo">
                    <label for="fecha_estimada">Fecha estimada</label>
                    <input class="input" type="date" id="fecha_estimada" name="fecha_estimada" min="<?= e(date('Y-m-d')) ?>" value="<?= e(viejo('fecha_estimada')) ?>">
                </div>
            </div>
            <div class="campo-fila">
                <div class="campo">
                    <label for="aforo">Número de invitados</label>
                    <input class="input" type="number" id="aforo" name="aforo" min="1" max="5000" value="<?= e(viejo('aforo')) ?>">
                </div>
                <div class="campo">
                    <label for="telefono">Teléfono de contacto</label>
                    <input class="input" type="tel" id="telefono" name="telefono" maxlength="25" value="<?= e(viejo('telefono', (string) ($cliente['telefono'] ?? ''))) ?>">
                </div>
            </div>
            <div class="campo">
                <label for="mensaje">Detalles</label>
                <textarea class="textarea" id="mensaje" name="mensaje" maxlength="1000" placeholder="Estilo, presupuesto aproximado, necesidades especiales…"><?= e(viejo('mensaje')) ?></textarea>
            </div>
            <button class="btn btn--lima" type="submit"><?= icono('correo') ?> Enviar solicitud</button>
        </form>
    </div>
</section>
