<?php
/** @var array $evento */
/** @var array $espacios */
/** @var array $programa */
/** @var array $servicios */
/** @var array $cotizaciones */
/** @var array $rsvp */
$idEvento = (int) $evento['id_evento'];
$saldo = array_sum(array_column($cotizaciones, 'saldo'));
$totalInvitados = array_sum($rsvp);
$confirmados = (int) ($rsvp['confirmado'] ?? 0);
$faltan = (int) floor((strtotime(date('Y-m-d', strtotime($evento['fecha_inicio']))) - strtotime(date('Y-m-d'))) / 86400);
?>
<div class="page-head">
    <div>
        <p class="page-head__eyebrow"><?= e($evento['tipo']) ?> · Evento #<?= $idEvento ?></p>
        <h1><?= e($evento['nombre']) ?></h1>
        <p class="page-head__sub"><?= e(fecha_larga($evento['fecha_inicio'])) ?>, <?= e(date('H:i', strtotime($evento['fecha_inicio']))) ?> a <?= e(date('H:i', strtotime($evento['fecha_fin']))) ?> h</p>
    </div>
    <div class="page-head__acciones">
        <?= badge_estado($evento['estado']) ?>
        <a class="btn btn--claro" href="<?= e(url('/cliente/eventos/' . $idEvento . '/invitados')) ?>"><?= icono('invitados') ?> Invitados</a>
    </div>
</div>

<?php if ($evento['estado'] === 'cancelado' && $evento['motivo_cancelacion']): ?>
    <div class="flash flash--error" role="status"><?= icono('alerta') ?><span>Evento cancelado: <?= e($evento['motivo_cancelacion']) ?></span></div>
<?php endif; ?>

<div class="kpis">
    <article class="kpi kpi--oscura">
        <p class="kpi__top"><?= icono('calendario') ?> Fecha</p>
        <p class="kpi__valor"><?= e(fecha($evento['fecha_inicio'], 'd M Y')) ?></p>
        <p class="kpi__nota"><?= $faltan > 0 ? 'Faltan ' . $faltan . ($faltan === 1 ? ' día' : ' días') : ($faltan === 0 ? 'Es hoy' : 'Ya pasó la fecha') ?></p>
    </article>
    <article class="kpi">
        <p class="kpi__top"><?= icono('invitados') ?> Invitados</p>
        <p class="kpi__valor"><?= $confirmados ?>/<?= (int) $evento['aforo_estimado'] ?></p>
        <p class="kpi__nota">Confirmados / aforo estimado</p>
    </article>
    <article class="kpi">
        <p class="kpi__top"><?= icono('pagos') ?> Saldo</p>
        <p class="kpi__valor"><?= e(money_corto($saldo)) ?></p>
        <p class="kpi__nota">Cotizaciones aceptadas</p>
    </article>
</div>

<div class="grid-detalle">
    <div class="stack">
        <section class="card">
            <div class="card__head"><div><h2>Programa del día</h2><p>Horarios y responsables.</p></div></div>
            <?php if ($programa === []): ?>
                <div class="empty"><h3>Programa por definir</h3><p>Tu coordinador lo publicará aquí cuando esté listo.</p></div>
            <?php else: ?>
                <div class="tabla-wrap"><table class="tabla">
                    <thead><tr><th>Hora</th><th>Actividad</th><th>Responsable</th></tr></thead>
                    <tbody>
                    <?php foreach ($programa as $p): ?>
                        <tr>
                            <td class="texto-sm"><b><?= e(date('H:i', strtotime($p['inicio']))) ?></b><?= $p['fin'] ? ' – ' . e(date('H:i', strtotime($p['fin']))) : '' ?></td>
                            <td><?= e($p['actividad']) ?></td>
                            <td class="texto-muted"><?= e($p['responsable'] ?: '—') ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table></div>
            <?php endif; ?>
        </section>

        <section class="card">
            <div class="card__head"><div><h2>Servicios contratados</h2><p>Lo que incluye tu evento.</p></div></div>
            <?php if ($servicios === []): ?>
                <div class="empty"><h3>Sin servicios adicionales</h3><p>Tu cotización detalla lo que está incluido.</p></div>
            <?php else: ?>
                <div class="card__body lista-datos">
                    <?php foreach ($servicios as $s): ?>
                        <div class="lista-datos__fila"><span><?= e($s['nombre']) ?> <span class="texto-muted texto-xs">× <?= (int) $s['cantidad'] ?></span></span><b><?= e(ucfirst(str_replace('_', ' ', $s['categoria']))) ?></b></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </div>

    <div class="stack">
        <section class="card">
            <div class="card__head"><div><h2>Detalles</h2></div></div>
            <div class="card__body lista-datos">
                <?php foreach ($espacios as $es): ?>
                    <div class="lista-datos__fila"><span>Espacio</span><b><?= e($es['nombre']) ?> · hasta <?= (int) $es['capacidad'] ?> personas</b></div>
                <?php endforeach; ?>
                <?php if ($espacios === []): ?><div class="lista-datos__fila"><span>Espacio</span><b>Por asignar</b></div><?php endif; ?>
                <div class="lista-datos__fila"><span>Aforo estimado / máximo</span><b><?= (int) $evento['aforo_estimado'] ?> / <?= (int) $evento['aforo_maximo'] ?></b></div>
                <?php if ($evento['descripcion']): ?><div class="lista-datos__fila"><span>Descripción</span><b><?= e($evento['descripcion']) ?></b></div><?php endif; ?>
            </div>
        </section>

        <section class="card">
            <div class="card__head"><div><h2>Cotizaciones</h2></div></div>
            <?php if ($cotizaciones === []): ?>
                <div class="empty"><h3>Sin cotizaciones</h3><p>Tu ejecutivo te enviará la propuesta.</p></div>
            <?php else: ?>
                <div class="card__body lista-datos">
                    <?php foreach ($cotizaciones as $c): if ($c['estado'] === 'borrador') { continue; } ?>
                        <div class="lista-datos__fila">
                            <span><a href="<?= e(url('/cliente/cotizaciones/' . (int) $c['id_cotizacion'])) ?>"><b><?= e($c['folio']) ?></b></a> <?= badge_estado($c['estado']) ?></span>
                            <b><?= e(money($c['total'])) ?></b>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <?php if ($totalInvitados > 0): ?>
        <section class="card">
            <div class="card__head"><div><h2>Confirmaciones</h2></div>
                <div class="card__head__acciones"><a class="btn btn--claro btn--sm" href="<?= e(url('/cliente/eventos/' . $idEvento . '/invitados')) ?>">Ver lista <?= icono('flecha') ?></a></div></div>
            <div class="card__body">
                <?php foreach (['confirmado' => 'Confirmados', 'pendiente' => 'Pendientes', 'lista_espera' => 'Lista de espera', 'declinado' => 'Declinaron'] as $k => $etq): $n = (int) ($rsvp[$k] ?? 0); ?>
                    <p class="texto-sm"><?= e($etq) ?> · <b><?= $n ?></b></p>
                    <div class="progreso"><span data-barra="<?= (int) round(($n / $totalInvitados) * 100) ?>" style="width:0"></span></div>
                <?php endforeach; ?>
            </div>
        </section>
        <?php endif; ?>
    </div>
</div>
