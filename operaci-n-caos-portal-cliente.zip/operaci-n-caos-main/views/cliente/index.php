<?php
/** @var array $cliente */
/** @var array $proximos */
/** @var array $porResponder */
/** @var float $saldo */
/** @var array $conSaldo */
$primero = $proximos[0] ?? null;
?>
<div class="page-head">
    <div>
        <p class="page-head__eyebrow">Portal del cliente</p>
        <h1>Hola, <?= e(explode(' ', trim($cliente['nombre']))[0]) ?></h1>
        <p class="page-head__sub">Aquí sigues tus eventos, respondes propuestas y consultas tu saldo.</p>
    </div>
    <div class="page-head__acciones">
        <a class="btn btn--lima" href="<?= e(url('/cliente/solicitar')) ?>"><?= icono('mas') ?> Solicitar evento</a>
    </div>
</div>

<div class="kpis">
    <article class="kpi kpi--oscura">
        <p class="kpi__top"><?= icono('calendario') ?> Próximo evento</p>
        <p class="kpi__valor"><?= $primero ? e(fecha($primero['fecha_inicio'], 'd M')) : '—' ?></p>
        <p class="kpi__nota"><?= $primero ? e($primero['nombre']) : 'Aún no tienes eventos programados' ?></p>
    </article>
    <article class="kpi">
        <p class="kpi__top"><?= icono('cotizacion') ?> Por responder</p>
        <p class="kpi__valor"><?= count($porResponder) ?></p>
        <p class="kpi__nota">Cotizaciones que esperan tu decisión</p>
    </article>
    <article class="kpi">
        <p class="kpi__top"><?= icono('pagos') ?> Saldo pendiente</p>
        <p class="kpi__valor"><?= e(money_corto($saldo)) ?></p>
        <p class="kpi__nota">En cotizaciones aceptadas</p>
    </article>
</div>

<div class="grid-detalle">
    <div class="stack">
        <section class="card">
            <div class="card__head">
                <div><h2>Próximos eventos</h2><p>Los siguientes en tu calendario.</p></div>
                <div class="card__head__acciones"><a class="btn btn--claro btn--sm" href="<?= e(url('/cliente/eventos')) ?>">Ver todos <?= icono('flecha') ?></a></div>
            </div>
            <?php if ($proximos === []): ?>
                <div class="empty">
                    <div class="empty__icono"><?= icono('calendario') ?></div>
                    <h3>Sin eventos próximos</h3>
                    <p>Cuando quieras organizar algo, solicítalo y tu ejecutivo te contactará.</p>
                </div>
            <?php else: ?>
                <div class="tabla-wrap">
                    <table class="tabla">
                        <thead><tr><th>Evento</th><th>Fecha</th><th class="num">Invitados</th><th>Estado</th></tr></thead>
                        <tbody>
                        <?php foreach ($proximos as $ev): ?>
                            <tr>
                                <td>
                                    <a class="tabla__principal" href="<?= e(url('/cliente/eventos/' . (int) $ev['id_evento'])) ?>">
                                        <span class="tabla__avatar"><?= icono(tipo_evento_icono($ev['tipo'])) ?></span>
                                        <span><b><?= e($ev['nombre']) ?></b><span><?= e($ev['tipo']) ?></span></span>
                                    </a>
                                </td>
                                <td><b class="texto-sm"><?= e(fecha($ev['fecha_inicio'], 'd M Y')) ?></b><span class="texto-muted texto-xs"><?= e(date('H:i', strtotime($ev['fecha_inicio']))) ?> h</span></td>
                                <td class="num"><?= (int) $ev['aforo_estimado'] ?></td>
                                <td><?= badge_estado($ev['estado']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>
    </div>

    <div class="stack">
        <section class="card">
            <div class="card__head"><div><h2>Esperan tu respuesta</h2><p>Acepta o rechaza cada propuesta.</p></div></div>
            <?php if ($porResponder === []): ?>
                <div class="empty"><h3>Todo al día</h3><p>No tienes cotizaciones pendientes.</p></div>
            <?php else: ?>
                <div class="card__body lista-datos">
                    <?php foreach ($porResponder as $c): ?>
                        <div class="lista-datos__fila">
                            <span><a href="<?= e(url('/cliente/cotizaciones/' . (int) $c['id_cotizacion'])) ?>"><b><?= e($c['folio']) ?></b></a><br><span class="texto-muted texto-xs"><?= e($c['evento']) ?><?= $c['vigencia_hasta'] ? ' · vigente hasta ' . e(fecha($c['vigencia_hasta'])) : '' ?></span></span>
                            <b><?= e(money($c['total'])) ?></b>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <section class="card">
            <div class="card__head"><div><h2>Saldo por pagar</h2><p>Por cotización aceptada.</p></div>
                <div class="card__head__acciones"><a class="btn btn--claro btn--sm" href="<?= e(url('/cliente/pagos')) ?>">Detalle <?= icono('flecha') ?></a></div></div>
            <?php if ($conSaldo === []): ?>
                <div class="empty"><h3>Sin saldo pendiente</h3><p>No tienes pagos por realizar.</p></div>
            <?php else: ?>
                <div class="card__body lista-datos">
                    <?php foreach ($conSaldo as $c): ?>
                        <div class="lista-datos__fila"><span><?= e($c['evento']) ?> · <?= e($c['folio']) ?></span><b><?= e(money($c['saldo'])) ?></b></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </div>
</div>
