<?php
/** @var array $cot */
/** @var array $detalle */
/** @var array $pagos */
$id = (int) $cot['id_cotizacion'];
$vencida = $cot['vigencia_hasta'] && strtotime($cot['vigencia_hasta']) < strtotime(date('Y-m-d'));
$avance = (float) $cot['total'] > 0 ? (int) min(100, round(($cot['pagado'] / (float) $cot['total']) * 100)) : 0;
$conceptos = ['espacio' => 'Espacio', 'menu' => 'Menú', 'servicio' => 'Servicio', 'recurso' => 'Recurso', 'otro' => 'Otro'];
?>
<div class="page-head">
    <div>
        <p class="page-head__eyebrow">Cotización · versión <?= (int) $cot['version'] ?></p>
        <h1><?= e($cot['folio']) ?></h1>
        <p class="page-head__sub"><a href="<?= e(url('/cliente/eventos/' . (int) $cot['id_evento'])) ?>"><?= e($cot['evento']) ?></a> · <?= e(fecha($cot['fecha_inicio'], 'd M Y')) ?></p>
    </div>
    <div class="page-head__acciones">
        <?= badge_estado($cot['estado']) ?>
        <button class="btn btn--claro" type="button" data-imprimir><?= icono('reportes') ?> Imprimir</button>
    </div>
</div>

<div class="grid-detalle">
    <div class="stack">
        <section class="card">
            <div class="card__head"><div><h2>Conceptos</h2><p>Precios unitarios y subtotales.</p></div></div>
            <div class="tabla-wrap">
                <table class="tabla">
                    <thead><tr><th>Concepto</th><th>Tipo</th><th class="num">Cant.</th><th class="num">Precio</th><th class="num">Subtotal</th></tr></thead>
                    <tbody>
                    <?php foreach ($detalle as $d): ?>
                        <tr>
                            <td><?= e($d['descripcion']) ?></td>
                            <td class="texto-muted"><?= e($conceptos[$d['tipo_concepto']] ?? $d['tipo_concepto']) ?></td>
                            <td class="num"><?= e(rtrim(rtrim(number_format((float) $d['cantidad'], 2, '.', ''), '0'), '.')) ?></td>
                            <td class="num"><?= e(money($d['precio_unitario'])) ?></td>
                            <td class="num"><b><?= e(money($d['subtotal'])) ?></b></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="card__body lista-datos">
                <div class="lista-datos__fila"><span>Subtotal</span><b><?= e(money($cot['subtotal'])) ?></b></div>
                <?php if ((float) $cot['descuento'] > 0): ?><div class="lista-datos__fila"><span>Descuento</span><b>− <?= e(money($cot['descuento'])) ?></b></div><?php endif; ?>
                <div class="lista-datos__fila"><span>Impuestos</span><b><?= e(money($cot['impuestos'])) ?></b></div>
                <div class="lista-datos__fila"><span><b>Total</b></span><b><?= e(money($cot['total'])) ?></b></div>
            </div>
            <?php if ($cot['notas']): ?><div class="card__body"><p class="texto-sm texto-muted"><?= e($cot['notas']) ?></p></div><?php endif; ?>
        </section>

        <?php if ($pagos !== []): ?>
        <section class="card">
            <div class="card__head"><div><h2>Pagos registrados</h2></div></div>
            <div class="tabla-wrap">
                <table class="tabla">
                    <thead><tr><th>Fecha</th><th>Tipo</th><th>Método</th><th>Referencia</th><th class="num">Monto</th></tr></thead>
                    <tbody>
                    <?php foreach ($pagos as $p): ?>
                        <tr>
                            <td class="texto-sm"><?= e(fecha($p['fecha_pago'], 'd M Y')) ?></td>
                            <td><?= e(ucfirst($p['tipo'])) ?></td>
                            <td><?= e(metodo_pago_etiqueta($p['metodo'])) ?></td>
                            <td class="texto-muted"><?= e($p['referencia'] ?: '—') ?></td>
                            <td class="num"><?= $p['tipo'] === 'devolucion' ? '− ' : '' ?><?= e(money($p['monto'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>
        <?php endif; ?>
    </div>

    <div class="stack">
        <?php if ($cot['estado'] === 'enviada'): ?>
        <section class="card">
            <div class="card__head"><div><h2>Tu decisión</h2>
                <p><?= $cot['vigencia_hasta'] ? ($vencida ? 'Esta propuesta venció el ' : 'Vigente hasta el ') . e(fecha($cot['vigencia_hasta'])) : 'Sin fecha de vencimiento' ?>.</p></div></div>
            <div class="card__body">
                <?php if ($vencida): ?>
                    <p class="texto-sm">La propuesta ya no está vigente. Pide una nueva versión a tu ejecutivo.</p>
                <?php else: ?>
                    <p class="texto-sm texto-muted mb-2">Al aceptar, los precios quedan congelados y se requiere un anticipo de <b><?= e(money($cot['anticipo_requerido'])) ?></b>.</p>
                    <form method="post" action="<?= e(url('/cliente/cotizaciones/' . $id . '/aceptar')) ?>" class="mb-2">
                        <?= csrf_field() ?>
                        <button class="btn btn--lima" type="submit"><?= icono('check') ?> Aceptar cotización</button>
                    </form>
                <?php endif; ?>
                <form method="post" action="<?= e(url('/cliente/cotizaciones/' . $id . '/rechazar')) ?>" class="formulario">
                    <?= csrf_field() ?>
                    <div class="campo">
                        <label for="motivo">¿Quieres rechazarla? Cuéntanos por qué (opcional)</label>
                        <textarea class="textarea" id="motivo" name="motivo" maxlength="220" placeholder="Presupuesto, fecha, alcance…"></textarea>
                    </div>
                    <button class="btn btn--claro" type="submit">Rechazar cotización</button>
                </form>
            </div>
        </section>
        <?php endif; ?>

        <?php if ($cot['estado'] === 'aceptada'): ?>
        <section class="card">
            <div class="card__head"><div><h2>Tu pago</h2><p>Aceptada el <?= e(fecha($cot['aceptada_en'])) ?>.</p></div></div>
            <div class="card__body">
                <div class="progreso progreso--ok"><span data-barra="<?= $avance ?>" style="width:0"></span></div>
                <div class="lista-datos mt-3">
                    <div class="lista-datos__fila"><span>Anticipo requerido</span><b><?= e(money($cot['anticipo_requerido'])) ?></b></div>
                    <div class="lista-datos__fila"><span>Pagado</span><b><?= e(money($cot['pagado'])) ?></b></div>
                    <div class="lista-datos__fila"><span>Saldo</span><b><?= e(money($cot['saldo'])) ?></b></div>
                </div>
                <p class="texto-xs texto-muted mt-3">Los pagos los registra el equipo de finanzas al recibirlos. Consulta el detalle en <a href="<?= e(url('/cliente/pagos')) ?>">Pagos y saldo</a>.</p>
            </div>
        </section>
        <?php endif; ?>

        <?php if (in_array($cot['estado'], ['rechazada', 'cancelada'], true)): ?>
        <section class="card"><div class="empty"><h3>Cotización <?= e($cot['estado'] === 'rechazada' ? 'rechazada' : 'cancelada') ?></h3>
            <p><?= $cot['motivo_cancelacion'] ? e($cot['motivo_cancelacion']) : 'Si quieres retomarla, pide una nueva versión a tu ejecutivo.' ?></p></div></section>
        <?php endif; ?>
    </div>
</div>
