<?php
/** @var array $pagos */
/** @var array $aceptadas */
/** @var float $total */
/** @var float $pagado */
/** @var float $saldo */
?>
<div class="page-head">
    <div>
        <p class="page-head__eyebrow">Portal del cliente</p>
        <h1>Pagos y saldo</h1>
        <p class="page-head__sub">Resumen de lo contratado, lo pagado y lo que falta por liquidar.</p>
    </div>
</div>

<div class="kpis">
    <article class="kpi kpi--oscura"><p class="kpi__top"><?= icono('cotizacion') ?> Contratado</p><p class="kpi__valor"><?= e(money_corto($total)) ?></p><p class="kpi__nota">Cotizaciones aceptadas</p></article>
    <article class="kpi"><p class="kpi__top"><?= icono('check') ?> Pagado</p><p class="kpi__valor"><?= e(money_corto($pagado)) ?></p><p class="kpi__nota">Neto de devoluciones</p></article>
    <article class="kpi"><p class="kpi__top"><?= icono('pagos') ?> Saldo</p><p class="kpi__valor"><?= e(money_corto($saldo)) ?></p><p class="kpi__nota">Por liquidar</p></article>
</div>

<div class="grid-detalle">
    <section class="card">
        <div class="card__head"><div><h2>Historial de pagos</h2><p>Los 200 movimientos más recientes.</p></div></div>
        <?php if ($pagos === []): ?>
            <div class="empty"><div class="empty__icono"><?= icono('pagos') ?></div><h3>Sin pagos registrados</h3><p>Cuando pagues tu anticipo, aparecerá aquí.</p></div>
        <?php else: ?>
            <div class="tabla-wrap">
                <table class="tabla">
                    <thead><tr><th>Fecha</th><th>Evento</th><th>Tipo</th><th>Método</th><th class="num">Monto</th></tr></thead>
                    <tbody>
                    <?php foreach ($pagos as $p): ?>
                        <tr>
                            <td class="texto-sm"><?= e(fecha($p['fecha_pago'], 'd M Y')) ?></td>
                            <td><a href="<?= e(url('/cliente/cotizaciones/' . (int) $p['id_cotizacion'])) ?>"><?= e($p['evento']) ?></a><span class="texto-muted texto-xs"><?= e($p['folio']) ?></span></td>
                            <td><?= e(ucfirst($p['tipo'])) ?></td>
                            <td><?= e(metodo_pago_etiqueta($p['metodo'])) ?><?= $p['referencia'] ? '<span class="texto-muted texto-xs">' . e($p['referencia']) . '</span>' : '' ?></td>
                            <td class="num"><?= $p['tipo'] === 'devolucion' ? '− ' : '' ?><?= e(money($p['monto'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>

    <section class="card">
        <div class="card__head"><div><h2>Por cotización</h2></div></div>
        <?php if ($aceptadas === []): ?>
            <div class="empty"><h3>Sin cotizaciones aceptadas</h3><p>El saldo aparece al aceptar una propuesta.</p></div>
        <?php else: ?>
            <div class="card__body">
                <?php foreach ($aceptadas as $c): $av = (float) $c['total'] > 0 ? (int) min(100, round(($c['pagado'] / (float) $c['total']) * 100)) : 0; ?>
                    <p class="texto-sm"><a href="<?= e(url('/cliente/cotizaciones/' . (int) $c['id_cotizacion'])) ?>"><b><?= e($c['evento']) ?></b></a> · <?= e($c['folio']) ?></p>
                    <div class="progreso progreso--ok"><span data-barra="<?= $av ?>" style="width:0"></span></div>
                    <p class="texto-xs texto-muted mb-2"><?= e(money($c['pagado'])) ?> de <?= e(money($c['total'])) ?> · saldo <b><?= e(money($c['saldo'])) ?></b></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
</div>
