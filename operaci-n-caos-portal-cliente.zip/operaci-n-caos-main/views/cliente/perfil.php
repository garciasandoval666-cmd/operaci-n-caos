<?php
/** @var array $cliente */
?>
<div class="page-head">
    <div>
        <p class="page-head__eyebrow">Cuenta</p>
        <h1>Mi perfil</h1>
        <p class="page-head__sub"><?= $cliente['tipo_cliente'] === 'empresa' ? 'Empresa' : 'Persona física' ?><?= $cliente['razon_social'] ? ' · ' . e($cliente['razon_social']) : '' ?> · Cliente desde <?= e(fecha($cliente['creado_en'], 'M Y')) ?></p>
    </div>
</div>

<div class="grid grid-2">
    <section class="card">
        <div class="card__head"><div><h2>Datos de contacto</h2><p>Nombre y correo los administra el equipo; escríbenos si cambian.</p></div></div>
        <div class="card__body">
            <form class="formulario" method="post" action="<?= e(url('/cliente/perfil')) ?>" novalidate>
                <?= csrf_field() ?>
                <div class="campo"><label for="nombre">Nombre</label><input class="input" id="nombre" type="text" value="<?= e($cliente['nombre']) ?>" disabled></div>
                <div class="campo"><label for="correo">Correo</label><input class="input" id="correo" type="email" value="<?= e($cliente['correo']) ?>" disabled></div>
                <div class="campo-fila">
                    <div class="campo"><label for="telefono">Teléfono</label><input class="input" id="telefono" name="telefono" type="tel" maxlength="25" value="<?= e((string) ($cliente['telefono'] ?? '')) ?>"></div>
                    <div class="campo"><label for="direccion">Dirección</label><input class="input" id="direccion" name="direccion" type="text" maxlength="220" value="<?= e((string) ($cliente['direccion'] ?? '')) ?>"></div>
                </div>
                <button class="btn btn--lima" type="submit"><?= icono('check') ?> Guardar cambios</button>
            </form>
        </div>
    </section>

    <section class="card">
        <div class="card__head"><div><h2>Contraseña</h2><p>Mínimo 8 caracteres.</p></div></div>
        <div class="card__body">
            <form class="formulario" method="post" action="<?= e(url('/cliente/perfil/clave')) ?>" autocomplete="off" novalidate>
                <?= csrf_field() ?>
                <div class="campo"><label for="clave_actual">Contraseña actual</label><input class="input" id="clave_actual" name="clave_actual" type="password" autocomplete="current-password" required></div>
                <div class="campo"><label for="clave_nueva">Nueva contraseña</label><input class="input" id="clave_nueva" name="clave_nueva" type="password" minlength="8" autocomplete="new-password" required></div>
                <div class="campo"><label for="clave_confirma">Confirmar nueva contraseña</label><input class="input" id="clave_confirma" name="clave_confirma" type="password" minlength="8" autocomplete="new-password" required></div>
                <button class="btn btn--primario" type="submit"><?= icono('candado') ?> Cambiar contraseña</button>
            </form>
        </div>
    </section>
</div>
