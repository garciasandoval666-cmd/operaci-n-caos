<?php
/** @var array $cotizaciones */
/** @var string $estado */
$etiquetas = ['' => 'Todas', 'enviada' => 'Por responder', 'aceptada' => 'Aceptadas', 'rechazada' => 'Rechazadas', 'cancelada' => 'Canceladas'];
?>
<div class="page-head">
    <div>
        <p class="page-head__eyebrow">Portal del cliente</p>
        <h1>Mis cotizaciones</h1>
        <p class="page-head__sub">Propuestas que te envió el equipo comercial. Los precios se congelan al aceptar.</p>
    </div>
    <div class="page-head__acciones">
        <?php foreach ($etiquetas as $clave => $etq): ?>
            <a class="btn btn--sm <?= $estado === $clave ? 'btn--primario' : 'btn--claro' ?>" href="<?= e(url('/cliente/cotizaciones' . ($clave !== '' ? '?estado=' . $clave : ''))) ?>"><?= e($etq) ?></a>
        <?php endforeach; ?>
    </div>
</div>

<section class="card">
    <?php if ($cotizaciones === []): ?>
        <div class="empty">
            <div class="empty__icono"><?= icono('cotizacion') ?></div>
            <h3>No hay cotizaciones en esta vista</h3>
            <p>Cuando tu ejecutivo te envíe una propuesta, aparecerá aquí.</p>
        </div>
    <?php else: ?>
        <div class="tabla-wrap">
            <table class="tabla">
                <thead><tr><th>Folio</th><th>Evento</th><th class="num">Total</th><th class="num">Pagado</th><th class="num">Saldo</th><th>Vigencia</th><th>Estado</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($cotizaciones as $c): ?>
                    <tr>
                        <td><b><?= e($c['folio']) ?></b><span class="texto-muted texto-xs">Versión <?= (int) $c['version'] ?></span></td>
                        <td><a href="<?= e(url('/cliente/eventos/' . (int) $c['id_evento'])) ?>"><?= e($c['evento']) ?></a></td>
                        <td class="num"><?= e(money($c['total'])) ?></td>
                        <td class="num"><?= $c['pagado'] > 0 ? e(money($c['pagado'])) : '—' ?></td>
                        <td class="num"><?= $c['saldo'] > 0 ? e(money($c['saldo'])) : '—' ?></td>
                        <td class="texto-sm"><?= $c['vigencia_hasta'] ? e(fecha($c['vigencia_hasta'])) : '—' ?></td>
                        <td><?= badge_estado($c['estado']) ?></td>
                        <td class="num"><a class="btn btn--claro btn--sm" href="<?= e(url('/cliente/cotizaciones/' . (int) $c['id_cotizacion'])) ?>"><?= $c['estado'] === 'enviada' ? 'Revisar' : 'Ver' ?> <?= icono('flecha') ?></a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
