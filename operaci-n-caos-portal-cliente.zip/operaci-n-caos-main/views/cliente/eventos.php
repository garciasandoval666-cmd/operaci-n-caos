<?php
/** @var array $eventos */
/** @var array $saldos */
/** @var string $vista */
$filtros = ['proximos' => 'Próximos', 'pasados' => 'Pasados', 'todos' => 'Todos'];
?>
<div class="page-head">
    <div>
        <p class="page-head__eyebrow">Portal del cliente</p>
        <h1>Mis eventos</h1>
        <p class="page-head__sub">Estado, fecha y saldo de cada uno de tus eventos.</p>
    </div>
    <div class="page-head__acciones">
        <?php foreach ($filtros as $clave => $etiqueta): ?>
            <a class="btn btn--sm <?= $vista === $clave ? 'btn--primario' : 'btn--claro' ?>" href="<?= e(url('/cliente/eventos?ver=' . $clave)) ?>"><?= e($etiqueta) ?></a>
        <?php endforeach; ?>
    </div>
</div>

<section class="card">
    <?php if ($eventos === []): ?>
        <div class="empty">
            <div class="empty__icono"><?= icono('calendario') ?></div>
            <h3>No hay eventos en esta vista</h3>
            <p>Prueba con otro filtro o solicita un evento nuevo.</p>
            <a class="btn btn--lima" href="<?= e(url('/cliente/solicitar')) ?>"><?= icono('mas') ?> Solicitar evento</a>
        </div>
    <?php else: ?>
        <div class="tabla-wrap">
            <table class="tabla">
                <thead><tr><th>Evento</th><th>Fecha</th><th class="num">Aforo</th><th class="num">Saldo</th><th>Estado</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($eventos as $ev): ?>
                    <tr>
                        <td>
                            <a class="tabla__principal" href="<?= e(url('/cliente/eventos/' . (int) $ev['id_evento'])) ?>">
                                <span class="tabla__avatar"><?= icono(tipo_evento_icono($ev['tipo'])) ?></span>
                                <span><b><?= e($ev['nombre']) ?></b><span><?= e($ev['tipo']) ?></span></span>
                            </a>
                        </td>
                        <td><b class="texto-sm"><?= e(fecha($ev['fecha_inicio'], 'd M Y')) ?></b><span class="texto-muted texto-xs"><?= e(date('H:i', strtotime($ev['fecha_inicio']))) ?> h</span></td>
                        <td class="num"><?= (int) $ev['aforo_maximo'] ?></td>
                        <td class="num"><?= isset($saldos[(int) $ev['id_evento']]) && $saldos[(int) $ev['id_evento']] > 0 ? e(money($saldos[(int) $ev['id_evento']])) : '—' ?></td>
                        <td><?= badge_estado($ev['estado']) ?></td>
                        <td class="num"><a class="btn btn--claro btn--sm" href="<?= e(url('/cliente/eventos/' . (int) $ev['id_evento'])) ?>">Ver <?= icono('flecha') ?></a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
