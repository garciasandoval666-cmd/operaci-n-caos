<?php
/** @var array|null $usuario */
$u = usuario_actual();
$porResponder = 0;
if ($u && !empty($u['id_cliente'])) {
    $stmt = App\Core\Database::pdo()->prepare(
        "SELECT COUNT(*) FROM cotizaciones c JOIN eventos e ON e.id_evento = c.id_evento
          WHERE e.id_cliente = ? AND c.estado = 'enviada'"
    );
    $stmt->execute([(int) $u['id_cliente']]);
    $porResponder = (int) $stmt->fetchColumn();
}
?>
<aside class="sidebar" id="sidebar">
    <a class="sidebar__marca" href="<?= e(url('/cliente')) ?>">
        <span class="monograma"><?= logo() ?></span>
        <span>
            <b><?= e(marca()) ?></b>
            <span>Portal del cliente</span>
        </span>
    </a>

    <nav class="sidebar__nav" aria-label="Menú del portal">
        <div class="nav-grupo">
            <p class="nav-grupo__titulo">Mi evento</p>
            <a class="nav-item<?= ruta_actual() === '/cliente' ? ' activo' : '' ?>" href="<?= e(url('/cliente')) ?>"><?= icono('panel') ?> Inicio</a>
            <a class="nav-item<?= nav_activo('/cliente/eventos') ?>" href="<?= e(url('/cliente/eventos')) ?>"><?= icono('calendario') ?> Mis eventos</a>
            <a class="nav-item<?= nav_activo('/cliente/solicitar') ?>" href="<?= e(url('/cliente/solicitar')) ?>"><?= icono('correo') ?> Solicitar evento</a>
        </div>

        <div class="nav-grupo">
            <p class="nav-grupo__titulo">Propuestas y pagos</p>
            <a class="nav-item<?= nav_activo('/cliente/cotizaciones') ?>" href="<?= e(url('/cliente/cotizaciones')) ?>">
                <?= icono('cotizacion') ?> Cotizaciones
                <?php if ($porResponder > 0): ?><span class="nav-item__cuenta"><?= $porResponder ?></span><?php endif; ?>
            </a>
            <a class="nav-item<?= nav_activo('/cliente/pagos') ?>" href="<?= e(url('/cliente/pagos')) ?>"><?= icono('pagos') ?> Pagos y saldo</a>
        </div>

        <div class="nav-grupo">
            <p class="nav-grupo__titulo">Cuenta</p>
            <a class="nav-item<?= nav_activo('/cliente/perfil') ?>" href="<?= e(url('/cliente/perfil')) ?>"><?= icono('usuarios') ?> Mi perfil</a>
        </div>
    </nav>

    <div class="sidebar__pie">
        <?php if ($u): ?>
            <div class="usuario-mini-fila">
                <a class="usuario-mini" href="<?= e(url('/cliente/perfil')) ?>">
                    <span class="usuario-mini__avatar"><?= e(iniciales($u['nombre'])) ?></span>
                    <span class="usuario-mini__datos">
                        <b><?= e($u['nombre']) ?></b>
                        <span>Cliente</span>
                    </span>
                </a>
                <form class="usuario-mini__forma" method="post" action="<?= e(url('/logout')) ?>">
                    <?= csrf_field() ?>
                    <button class="usuario-mini__salir" type="submit" title="Cerrar sesión" aria-label="Cerrar sesión"><?= icono('salir') ?></button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</aside>
