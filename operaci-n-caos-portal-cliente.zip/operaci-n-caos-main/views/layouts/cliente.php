<?php
/** @var string $contenido */
/** @var array|null $usuario */
$titulo = $titulo ?? 'Mi portal';
$migas = $migas ?? [];
$flash = $flash ?? '';
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#090b0f">
    <title><?= e($titulo) ?> · <?= e(marca()) ?></title>
    <link rel="icon" href="<?= e(asset('assets/img/favicon.svg')) ?>" type="image/svg+xml">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Mona+Sans:wght@400;500;600;700;800&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= e(asset('assets/css/app.css')) ?>">
</head>
<body data-base="<?= e(base_url()) ?>">
<div class="admin">
    <?php require BASE_PATH . '/views/partials/cliente-nav.php'; ?>

    <div class="main">
        <header class="topbar">
            <button type="button" class="btn-icono topbar__menu" data-sidebar-toggle aria-label="Abrir menú" aria-expanded="false">
                <?= icono('menu') ?>
            </button>

            <nav class="migas" aria-label="Ruta">
                <a href="<?= e(url('/cliente')) ?>"><?= icono('casa') ?> Mi portal</a>
                <?php foreach ($migas as $miga): ?>
                    <?= icono('flecha') ?>
                    <?php if (!empty($miga['url'])): ?>
                        <a href="<?= e(url($miga['url'])) ?>"><?= e($miga['titulo']) ?></a>
                    <?php else: ?>
                        <b><?= e($miga['titulo']) ?></b>
                    <?php endif; ?>
                <?php endforeach; ?>
            </nav>

            <div class="topbar__acciones">
                <a class="topbar__enlace" href="<?= e(url('/')) ?>" target="_blank" rel="noopener">
                    <?= icono('externo') ?><span>Ver sitio</span>
                </a>
                <a class="btn btn--lima btn--sm" href="<?= e(url('/cliente/solicitar')) ?>"><?= icono('mas') ?> Solicitar evento</a>
            </div>
        </header>

        <main class="contenido">
            <?= $flash ?>
            <?= $contenido ?>
        </main>
    </div>
</div>
<script src="<?= e(asset('assets/js/app.js')) ?>" defer></script>
</body>
</html>
