<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\View;
use App\Domain\Cotizaciones;
use PDO;
use RuntimeException;

/**
 * Portal del cliente.
 *
 * Todo lo que se lee o se escribe aquí queda acotado al expediente ligado a la
 * cuenta (`usuarios.id_cliente`). Ninguna consulta recibe el cliente por la
 * URL: un id ajeno en la ruta responde 404, igual que uno inexistente.
 */
final class ClienteController extends Controller
{
    private ?array $expediente = null;

    /* ------------------------------------------------------------------
     * Ayudantes
     * ------------------------------------------------------------------ */

    private function pdo(): PDO
    {
        return Database::pdo();
    }

    private function expediente(): array
    {
        if ($this->expediente !== null) {
            return $this->expediente;
        }
        $idCliente = (int) (Auth::usuario()['id_cliente'] ?? 0);
        $stmt = $this->pdo()->prepare('SELECT * FROM clientes WHERE id_cliente = ? LIMIT 1');
        $stmt->execute([$idCliente]);
        $cliente = $stmt->fetch();
        if (!$cliente) {
            http_response_code(403);
            View::render('errores/403', ['titulo' => 'Cuenta sin expediente'], 'cliente');
            exit;
        }
        return $this->expediente = $cliente;
    }

    private function idCliente(): int
    {
        return (int) $this->expediente()['id_cliente'];
    }

    private function render(string $vista, string $titulo, array $datos = [], array $migas = []): void
    {
        View::render('cliente/' . $vista, $datos + [
            'titulo'  => $titulo,
            'migas'   => $migas,
            'cliente' => $this->expediente(),
        ], 'cliente');
    }

    /** Evento propio o 404. */
    private function eventoPropio(int $id): array
    {
        $stmt = $this->pdo()->prepare(
            'SELECT e.*, t.nombre AS tipo, t.requiere_rsvp, t.requiere_mesas
               FROM eventos e JOIN tipos_evento t ON t.id_tipo_evento = e.id_tipo_evento
              WHERE e.id_evento = ? AND e.id_cliente = ? LIMIT 1'
        );
        $stmt->execute([$id, $this->idCliente()]);
        $evento = $stmt->fetch();
        if (!$evento) {
            $this->noEncontrado('No encontramos ese evento en tu cuenta.');
        }
        return $evento;
    }

    /** Cotizaciones del cliente con lo pagado y el saldo (mismo criterio que saldo_cotizacion()). */
    private function cotizaciones(?int $idEvento = null): array
    {
        $sql = "SELECT c.*, e.nombre AS evento, e.fecha_inicio,
                       COALESCE((SELECT SUM(CASE WHEN p.tipo = 'devolucion' THEN -p.monto ELSE p.monto END)
                                   FROM pagos p
                                  WHERE p.id_cotizacion = c.id_cotizacion AND p.estado <> 'revertido'), 0) AS pagado
                  FROM cotizaciones c
                  JOIN eventos e ON e.id_evento = c.id_evento
                 WHERE e.id_cliente = ?";
        $params = [$this->idCliente()];
        if ($idEvento !== null) {
            $sql .= ' AND c.id_evento = ?';
            $params[] = $idEvento;
        }
        $stmt = $this->pdo()->prepare($sql . ' ORDER BY c.creado_en DESC, c.id_cotizacion DESC');
        $stmt->execute($params);
        $filas = $stmt->fetchAll();
        foreach ($filas as &$f) {
            $f['pagado'] = (float) $f['pagado'];
            $f['saldo'] = $f['estado'] === 'aceptada' ? max(0.0, (float) $f['total'] - $f['pagado']) : 0.0;
        }
        return $filas;
    }

    /** Cotización propia (por su evento) o 404. */
    private function cotizacionPropia(int $id): array
    {
        foreach ($this->cotizaciones() as $c) {
            if ((int) $c['id_cotizacion'] === $id) {
                return $c;
            }
        }
        $this->noEncontrado('No encontramos esa cotización en tu cuenta.');
    }

    /* ------------------------------------------------------------------
     * Inicio
     * ------------------------------------------------------------------ */

    public function inicio(): void
    {
        $stmt = $this->pdo()->prepare(
            "SELECT e.*, t.nombre AS tipo FROM eventos e
               JOIN tipos_evento t ON t.id_tipo_evento = e.id_tipo_evento
              WHERE e.id_cliente = ? AND e.estado NOT IN ('cancelado','cerrado','realizado') AND e.fecha_fin >= NOW()
              ORDER BY e.fecha_inicio LIMIT 5"
        );
        $stmt->execute([$this->idCliente()]);
        $proximos = $stmt->fetchAll();

        $cotizaciones = $this->cotizaciones();
        $porResponder = array_values(array_filter($cotizaciones, static fn (array $c): bool => $c['estado'] === 'enviada'));
        $saldo = array_sum(array_column($cotizaciones, 'saldo'));

        $this->render('index', 'Mi portal', [
            'proximos'     => $proximos,
            'porResponder' => $porResponder,
            'saldo'        => (float) $saldo,
            'conSaldo'     => array_values(array_filter($cotizaciones, static fn (array $c): bool => $c['saldo'] > 0)),
        ]);
    }

    /* ------------------------------------------------------------------
     * Eventos
     * ------------------------------------------------------------------ */

    public function eventos(): void
    {
        $vista = $this->filtro('ver', ['proximos', 'pasados', 'todos'], 'proximos');
        $condicion = match ($vista) {
            'proximos' => "AND e.estado NOT IN ('cancelado','cerrado','realizado') AND e.fecha_fin >= NOW()",
            'pasados'  => "AND (e.estado IN ('cancelado','cerrado','realizado') OR e.fecha_fin < NOW())",
            default    => '',
        };
        $stmt = $this->pdo()->prepare(
            "SELECT e.*, t.nombre AS tipo FROM eventos e
               JOIN tipos_evento t ON t.id_tipo_evento = e.id_tipo_evento
              WHERE e.id_cliente = ? $condicion ORDER BY e.fecha_inicio DESC"
        );
        $stmt->execute([$this->idCliente()]);
        $eventos = $stmt->fetchAll();

        $saldos = [];
        foreach ($this->cotizaciones() as $c) {
            $saldos[(int) $c['id_evento']] = ($saldos[(int) $c['id_evento']] ?? 0.0) + $c['saldo'];
        }

        $this->render('eventos', 'Mis eventos', [
            'eventos' => $eventos,
            'saldos'  => $saldos,
            'vista'   => $vista,
        ], [['titulo' => 'Mis eventos']]);
    }

    public function evento(array $params): void
    {
        $evento = $this->eventoPropio((int) ($params['id'] ?? 0));
        $id = (int) $evento['id_evento'];
        $pdo = $this->pdo();

        $consulta = static function (PDO $pdo, string $sql, int $id): array {
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$id]);
            return $stmt->fetchAll();
        };

        $espacios = $consulta($pdo,
            "SELECT s.nombre, s.capacidad, r.fecha_inicio, r.fecha_fin
               FROM reservas_espacio r JOIN espacios s ON s.id_espacio = r.id_espacio
              WHERE r.id_evento = ? AND r.estado = 'confirmada' ORDER BY r.fecha_inicio", $id);
        $programa = $consulta($pdo,
            'SELECT inicio, fin, actividad, responsable FROM evento_programa WHERE id_evento = ? ORDER BY inicio', $id);
        $servicios = $consulta($pdo,
            'SELECT s.nombre, s.categoria, es.cantidad, es.precio_unitario
               FROM evento_servicios es JOIN servicios s ON s.id_servicio = es.id_servicio
              WHERE es.id_evento = ? ORDER BY s.categoria, s.nombre', $id);
        $rsvp = $consulta($pdo,
            'SELECT estado_rsvp, COUNT(*) AS total FROM invitados WHERE id_evento = ? GROUP BY estado_rsvp', $id);

        $this->render('evento', $evento['nombre'], [
            'evento'       => $evento,
            'espacios'     => $espacios,
            'programa'     => $programa,
            'servicios'    => $servicios,
            'cotizaciones' => $this->cotizaciones($id),
            'rsvp'         => array_column($rsvp, 'total', 'estado_rsvp'),
        ], [['titulo' => 'Mis eventos', 'url' => '/cliente/eventos'], ['titulo' => $evento['nombre']]]);
    }

    public function invitados(array $params): void
    {
        $evento = $this->eventoPropio((int) ($params['id'] ?? 0));
        $estado = $this->filtro('estado', ['pendiente', 'confirmado', 'declinado', 'lista_espera']);

        $sql = 'SELECT i.nombre, i.categoria, i.estado_rsvp, i.restriccion_alimenticia, i.alergias,
                       i.token_acceso, i.checkin_en, m.numero AS mesa
                  FROM invitados i LEFT JOIN mesas m ON m.id_mesa = i.id_mesa
                 WHERE i.id_evento = ?';
        $args = [(int) $evento['id_evento']];
        if ($estado !== '') {
            $sql .= ' AND i.estado_rsvp = ?';
            $args[] = $estado;
        }
        $stmt = $this->pdo()->prepare($sql . ' ORDER BY i.nombre LIMIT 500');
        $stmt->execute($args);

        $stmt2 = $this->pdo()->prepare('SELECT estado_rsvp, COUNT(*) AS total FROM invitados WHERE id_evento = ? GROUP BY estado_rsvp');
        $stmt2->execute([(int) $evento['id_evento']]);

        $this->render('invitados', 'Invitados · ' . $evento['nombre'], [
            'evento'    => $evento,
            'invitados' => $stmt->fetchAll(),
            'rsvp'      => array_column($stmt2->fetchAll(), 'total', 'estado_rsvp'),
            'estado'    => $estado,
        ], [
            ['titulo' => 'Mis eventos', 'url' => '/cliente/eventos'],
            ['titulo' => $evento['nombre'], 'url' => '/cliente/eventos/' . (int) $evento['id_evento']],
            ['titulo' => 'Invitados'],
        ]);
    }

    /* ------------------------------------------------------------------
     * Cotizaciones
     * ------------------------------------------------------------------ */

    public function cotizacionesIndex(): void
    {
        $estado = $this->filtro('estado', ['enviada', 'aceptada', 'rechazada', 'cancelada']);
        $todas = $this->cotizaciones();
        $lista = $estado === '' ? $todas : array_values(array_filter($todas, static fn (array $c): bool => $c['estado'] === $estado));
        // El cliente no ve borradores: son trabajo interno del equipo comercial.
        $lista = array_values(array_filter($lista, static fn (array $c): bool => $c['estado'] !== 'borrador'));

        $this->render('cotizaciones', 'Mis cotizaciones', [
            'cotizaciones' => $lista,
            'estado'       => $estado,
        ], [['titulo' => 'Cotizaciones']]);
    }

    public function cotizacion(array $params): void
    {
        $cot = $this->cotizacionPropia((int) ($params['id'] ?? 0));
        if ($cot['estado'] === 'borrador') {
            $this->noEncontrado('Esa cotización todavía no está disponible.');
        }
        $id = (int) $cot['id_cotizacion'];

        $stmt = $this->pdo()->prepare('SELECT * FROM cotizacion_detalle WHERE id_cotizacion = ? ORDER BY id_detalle');
        $stmt->execute([$id]);
        $detalle = $stmt->fetchAll();

        $stmt = $this->pdo()->prepare("SELECT tipo, monto, metodo, referencia, estado, fecha_pago FROM pagos WHERE id_cotizacion = ? AND estado <> 'revertido' ORDER BY fecha_pago");
        $stmt->execute([$id]);

        $this->render('cotizacion', 'Cotización ' . $cot['folio'], [
            'cot'     => $cot,
            'detalle' => $detalle,
            'pagos'   => $stmt->fetchAll(),
        ], [['titulo' => 'Cotizaciones', 'url' => '/cliente/cotizaciones'], ['titulo' => $cot['folio']]]);
    }

    public function aceptar(array $params): void
    {
        $cot = $this->cotizacionPropia((int) ($params['id'] ?? 0));
        $ruta = '/cliente/cotizaciones/' . (int) $cot['id_cotizacion'];
        if ($cot['estado'] !== 'enviada') {
            $this->error('Solo puedes aceptar una cotización que el equipo ya te envió.', $ruta);
        }
        try {
            Cotizaciones::aceptar((int) $cot['id_cotizacion'], 'Aceptada por el cliente desde el portal');
        } catch (RuntimeException $e) {
            $this->error($e->getMessage(), $ruta);
        }
        $this->exito('Aceptaste la cotización. Los precios quedaron congelados; el equipo te contactará para el anticipo.', $ruta);
    }

    public function rechazar(array $params): void
    {
        $cot = $this->cotizacionPropia((int) ($params['id'] ?? 0));
        $id = (int) $cot['id_cotizacion'];
        $ruta = '/cliente/cotizaciones/' . $id;
        if ($cot['estado'] !== 'enviada') {
            $this->error('Solo puedes rechazar una cotización que está pendiente de respuesta.', $ruta);
        }
        $motivo = mb_substr($this->texto('motivo'), 0, 220);
        $this->pdo()->prepare("UPDATE cotizaciones SET estado = 'rechazada' WHERE id_cotizacion = ? AND estado = 'enviada'")->execute([$id]);
        registrar_historial('cotizaciones', $id, 'estado', 'enviada', 'rechazada', $motivo !== '' ? $motivo : 'Rechazada por el cliente desde el portal');
        registrar_bitacora('RECHAZAR_COTIZACION', 'cotizaciones', $id, $cot['folio'] . ' · rechazada por el cliente');
        $this->aviso('Rechazaste la cotización. Si cambias de opinión, pide una nueva versión a tu ejecutivo.', $ruta);
    }

    /* ------------------------------------------------------------------
     * Pagos
     * ------------------------------------------------------------------ */

    public function pagos(): void
    {
        $stmt = $this->pdo()->prepare(
            "SELECT p.*, c.folio, e.nombre AS evento, e.id_evento
               FROM pagos p
               JOIN cotizaciones c ON c.id_cotizacion = p.id_cotizacion
               JOIN eventos e ON e.id_evento = c.id_evento
              WHERE e.id_cliente = ? AND p.estado <> 'revertido'
              ORDER BY p.fecha_pago DESC, p.id_pago DESC LIMIT 200"
        );
        $stmt->execute([$this->idCliente()]);

        $aceptadas = array_values(array_filter($this->cotizaciones(), static fn (array $c): bool => $c['estado'] === 'aceptada'));

        $this->render('pagos', 'Mis pagos', [
            'pagos'     => $stmt->fetchAll(),
            'aceptadas' => $aceptadas,
            'total'     => (float) array_sum(array_column($aceptadas, 'total')),
            'pagado'    => (float) array_sum(array_column($aceptadas, 'pagado')),
            'saldo'     => (float) array_sum(array_column($aceptadas, 'saldo')),
        ], [['titulo' => 'Pagos']]);
    }

    /* ------------------------------------------------------------------
     * Solicitar un evento nuevo (entra a la bandeja de Solicitudes)
     * ------------------------------------------------------------------ */

    public function solicitar(): void
    {
        $tipos = $this->pdo()->query('SELECT nombre FROM tipos_evento WHERE activo = 1 ORDER BY nombre')->fetchAll(PDO::FETCH_COLUMN);
        $this->render('solicitar', 'Solicitar un evento', ['tipos' => $tipos], [['titulo' => 'Solicitar evento']]);
    }

    public function enviarSolicitud(): void
    {
        $cliente = $this->expediente();
        $tipo = mb_substr($this->texto('tipo_evento'), 0, 60);
        $fecha = $this->fecha('fecha_estimada');
        $aforo = $this->entero('aforo');
        $mensaje = mb_substr($this->texto('mensaje'), 0, 1000);
        $telefono = mb_substr($this->texto('telefono', (string) ($cliente['telefono'] ?? '')), 0, 25);

        recordar_viejos($_POST);
        if ($tipo === '') {
            $this->error('Elige el tipo de evento que quieres organizar.', '/cliente/solicitar');
        }
        if ($fecha !== null && $fecha < date('Y-m-d')) {
            $this->error('La fecha estimada no puede ser anterior a hoy.', '/cliente/solicitar');
        }
        if ($aforo < 0 || $aforo > 5000) {
            $this->error('El número de invitados no es válido.', '/cliente/solicitar');
        }

        $stmt = $this->pdo()->prepare(
            "INSERT INTO leads (nombre, correo, telefono, tipo_evento, fecha_estimada, aforo, mensaje, origen)
             VALUES (?, ?, ?, ?, ?, ?, ?, 'contacto')"
        );
        $stmt->execute([
            $cliente['nombre'], $cliente['correo'], $telefono !== '' ? $telefono : null,
            $tipo, $fecha, $aforo > 0 ? $aforo : null, $mensaje !== '' ? $mensaje : null,
        ]);
        registrar_bitacora('SOLICITUD_PORTAL', 'leads', (int) $this->pdo()->lastInsertId(), 'Solicitud desde el portal · ' . $tipo);
        limpiar_viejos();
        $this->exito('Recibimos tu solicitud. Tu ejecutivo comercial te contactará pronto.', '/cliente');
    }

    /* ------------------------------------------------------------------
     * Perfil
     * ------------------------------------------------------------------ */

    public function perfil(): void
    {
        $this->render('perfil', 'Mi perfil', [], [['titulo' => 'Mi perfil']]);
    }

    public function actualizarPerfil(): void
    {
        $telefono = mb_substr($this->texto('telefono'), 0, 25);
        $direccion = mb_substr($this->texto('direccion'), 0, 220);
        if ($telefono !== '' && !preg_match('/^[0-9+()\-\s.]{7,25}$/', $telefono)) {
            $this->error('El teléfono solo puede llevar números, espacios, +, - y paréntesis.', '/cliente/perfil');
        }
        $id = $this->idCliente();
        $this->pdo()->prepare('UPDATE clientes SET telefono = ?, direccion = ? WHERE id_cliente = ?')
            ->execute([$telefono !== '' ? $telefono : null, $direccion !== '' ? $direccion : null, $id]);
        registrar_bitacora('ACTUALIZAR_PERFIL_CLIENTE', 'clientes', $id, 'Contacto actualizado desde el portal');
        $this->exito('Actualizamos tus datos de contacto.', '/cliente/perfil');
    }

    public function cambiarClave(): void
    {
        $actual = (string) ($_POST['clave_actual'] ?? '');
        $nueva = (string) ($_POST['clave_nueva'] ?? '');
        $confirma = (string) ($_POST['clave_confirma'] ?? '');
        $idUsuario = (int) Auth::id();

        $stmt = $this->pdo()->prepare('SELECT password_hash FROM usuarios WHERE id_usuario = ?');
        $stmt->execute([$idUsuario]);
        if (!password_verify($actual, (string) $stmt->fetchColumn())) {
            $this->error('La contraseña actual no es correcta.', '/cliente/perfil');
        }
        if (mb_strlen($nueva) < 8) {
            $this->error('La nueva contraseña debe tener al menos 8 caracteres.', '/cliente/perfil');
        }
        if ($nueva !== $confirma) {
            $this->error('La confirmación no coincide con la nueva contraseña.', '/cliente/perfil');
        }
        $this->pdo()->prepare('UPDATE usuarios SET password_hash = ? WHERE id_usuario = ?')
            ->execute([password_hash($nueva, PASSWORD_DEFAULT), $idUsuario]);
        registrar_bitacora('CAMBIAR_CLAVE', 'usuarios', $idUsuario, 'Contraseña cambiada desde el portal');
        $this->exito('Tu contraseña se actualizó.', '/cliente/perfil');
    }
}
