-- Solera 1.3.0 · Portal del cliente
-- Añade el rol «cliente», liga cada cuenta a su expediente (usuarios.id_cliente)
-- y crea una cuenta demo. Es repetible: si ya se aplicó, no duplica nada.
-- Uso: mysql -u root -p conectaeventos < database/migracion-1.3.0.sql

SET @falta := (SELECT COUNT(*) = 0 FROM information_schema.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'usuarios' AND COLUMN_NAME = 'id_cliente');
SET @ddl := IF(@falta,
  'ALTER TABLE usuarios ADD COLUMN id_cliente INT NULL AFTER telefono, ADD CONSTRAINT fk_usuario_cliente FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente) ON DELETE SET NULL',
  'SELECT 1');
PREPARE paso FROM @ddl;
EXECUTE paso;
DEALLOCATE PREPARE paso;

INSERT INTO roles (nombre, descripcion)
SELECT 'cliente', 'Consulta sus eventos, cotizaciones, pagos e invitados desde el portal'
 WHERE NOT EXISTS (SELECT 1 FROM roles WHERE nombre = 'cliente');

INSERT INTO usuarios (id_rol, id_cliente, nombre, correo, password_hash, telefono)
SELECT r.id_rol, c.id_cliente, c.nombre, 'cliente@solera.mx', a.password_hash, c.telefono
  FROM eventos e
  JOIN clientes c ON c.id_cliente = e.id_cliente
  JOIN roles r ON r.nombre = 'cliente'
  JOIN usuarios a ON a.correo = 'admin@solera.mx'
 WHERE e.id_evento = 1
   AND NOT EXISTS (SELECT 1 FROM usuarios WHERE correo = 'cliente@solera.mx');
